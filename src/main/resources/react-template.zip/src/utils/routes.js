export const routes = [
  {
    path: '/page-one',
    name: 'Pagina uno'
  },
  {
    path: '/page-two',
    name: 'Pagina dos'
  }
]