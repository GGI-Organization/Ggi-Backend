import { Button, Link, Stack, Typography } from '@mui/material'
import React from 'react'
import styled from 'styled-components'
import { routes } from '../utils/routes'


function Layout({ children }) {


  const Container = styled.div`
    width: '100vw';
    height: '100vh';
  `

  const TopBar = styled.div`
    padding: 10px 0px;
    width: '100vw';
    background-color: #8ecae6;
  `

  return (
    <Container>
      <TopBar>
        <Stack gap={5} direction='row' justifyContent='center' >
          {routes.map((item, index) => (
            <Button key={index} sx={{ textTransform: 'none' }} LinkComponent={Link} href={item.path}>
              <Typography>
                {item.name}
              </Typography>
            </Button>
          ))}
        </Stack>
      </TopBar>
      {children}
    </Container>
  )
}

export default Layout