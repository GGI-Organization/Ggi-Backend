import { Box, InputAdornment, TextField } from '@mui/material'
import SearchOutlinedIcon from '@mui/icons-material/SearchOutlined';
import React from 'react'

function InputSearch({ width, height, positionX, positionY }) {
  return (
    <Box
      sx={{
        width: `${width}px`,
        // height: `${height}px`,
        left: `${positionX}px`,
        top: `${positionY}px`,
        position: 'absolute'
      }}
    >
      <TextField
        id="input-with-icon-textfield"
        fullWidth
        size='small'
        InputProps={{
          startAdornment: (
            <InputAdornment position="start">
              <SearchOutlinedIcon />
            </InputAdornment>
          ),
        }}
        placeholder='Ingrese busqueda'
        variant="outlined"
      />
    </Box>
  )
}

export default InputSearch