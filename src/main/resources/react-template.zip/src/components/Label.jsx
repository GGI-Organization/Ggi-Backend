import { Box, Typography } from '@mui/material'
import React from 'react'

function Label({ width, height, positionX, positionY }) {
  return (
    <Box
      sx={{
        // width: `${width}px`,
        // height: `${height}px`,
        left: `${positionX}px`,
        top: `${positionY}px`,
        position: 'absolute'
      }}
    >
      <Typography variant='h5'>Titulo</Typography>
    </Box>
  )
}

export default Label