import { Box, MenuItem, Select } from '@mui/material'
import React, { useState } from 'react'

function SelectC({ width, height, positionX, positionY }) {
  const [value, setValue] = useState('')

  return (
    <Box
      sx={{
        width: `${width}px`,
        // height: `${height}px`,
        left: `${positionX}px`,
        top: `${positionY}px`,
        position: 'absolute'
      }}
    >
      <Select
        labelId="demo-simple-select-label"
        id="demo-simple-select"
        size='small'
        fullWidth
        value={value}
        placeholder='[--Seleccionar--]'
        onChange={(e) => setValue(e.target.value)}
      >
        <MenuItem value={'opcion1'}>Opcion 1</MenuItem>
        <MenuItem value={'opicon2'}>Opcion 2</MenuItem>
      </Select>
    </Box>
  )
}

export default SelectC