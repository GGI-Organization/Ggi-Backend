import { Box, TextField } from '@mui/material'
import React from 'react'

function Input({ width, height, positionX, positionY}) {
  return (
    <Box
      sx={{
        width: `${width}px`,
        // height: `${height}px`,
        left: `${positionX}px`,
        top: `${positionY}px`,
        position: 'absolute'
      }}
    >
      <TextField fullWidth size='small' placeholder='Ingrese texto' variant="outlined" />
    </Box>
  )
}

export default Input