import React from 'react'
import Button from '@mui/material/Button';
import { Box, Typography } from '@mui/material';

function ButtonC({ width, height, positionX, positionY }) {
  return (
    <Box sx={{
      left: `${positionX}px`,
      top: `${positionY}px`,
      position: 'absolute'
    }}>
      <Button
        variant='contained'
        size='large'
        sx={{
          // width: `150px`,
          // height: `${height}px`,
          textTransform: 'none'
        }}>
        <Typography>Presionar</Typography>
      </Button>
    </Box>
  )
}

export default ButtonC