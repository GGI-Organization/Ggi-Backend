import { Box, Checkbox, FormControlLabel } from '@mui/material'
import React from 'react'

function CheckboxC({ width, height, positionX, positionY, label }) {
  return (
    <Box sx={{
      left: `${positionX}px`,
      top: `${positionY}px`,
      position: 'absolute'
    }}>
      <FormControlLabel
        value={label}
        control={<Checkbox />}
        label={label}
        labelPlacement="end"
      />
    </Box>
  )
}

export default CheckboxC