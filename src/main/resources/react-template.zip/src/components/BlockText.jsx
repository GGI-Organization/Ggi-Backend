import { Box, Typography } from '@mui/material'
import React from 'react'

function BlockText({ width, height, positionX, positionY, label, }) {
  return (
    <Box sx={{
      width: `${width}px`,
      height: `${height}px`,
      left: `${positionX}px`,
      top: `${positionY}px`,
      position: 'absolute'
    }}>
      <Typography variant='body1'>
        {label}
      </Typography>
    </Box>
  )
}

export default BlockText