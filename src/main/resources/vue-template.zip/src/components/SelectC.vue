<template>
  <div :style="style">
    <q-select outlined v-model="model" :options="options"  />
  </div>
</template>

<script>
import { ref } from 'vue'
export default {
  props: ['width', 'positionX', 'positionY'],
  setup () {
    return {
      model: ref('Ninguno'),
      options: [
        'Ninguno', 'Facebook', 'Google', 'Apple'
      ]
    }
  },
  computed: {
    style() {
      return `width: ${this.width}px;left: ${this.positionX}px;top: ${this.positionY}px;position: absolute;`
    },
  }
}
</script>