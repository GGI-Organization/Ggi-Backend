
<template>
  <div :style="style">
    <div class="text-body1">
      {{label}}
    </div>
  </div>
</template>

<script>
export default {
  props: ['label', 'width', 'height', 'positionX', 'positionY'],
  computed: {
    style() {
      return `width: ${this.width}px;height: ${this.height}px;left: ${this.positionX}px;top: ${this.positionY}px;position: absolute;`
    }
  }
}
</script>