<template>
  <div :style="style">
    <q-checkbox v-model="right" :label="label" />
  </div>
</template>

<script>
import { ref } from 'vue'
export default {
  props: ['label', 'width', 'height', 'positionX', 'positionY'],
  computed: {
    style() {
      return `left: ${this.positionX}px;top: ${this.positionY}px;position: absolute;`
    },
  },
  setup () {
    return {
      right: ref(false),
    }
  }
}
</script>