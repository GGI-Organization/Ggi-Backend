<template>
  <div :style="style">
    <q-input outlined v-model="text" placeholder="Ingrese texto" />
  </div>
</template>

<script>
export default {
  props: ['width', 'positionX', 'positionY'],
  computed: {
    style() {
      return `width: ${this.width}px;left: ${this.positionX}px;top: ${this.positionY}px;position: absolute;`
    },
  }
}
</script>