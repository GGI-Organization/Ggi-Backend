<template>
  <div :style="style">
    <q-btn :style="styledBtn" no-caps color="primary" class="text-body1" label="Boton" />
  </div>
</template>

<script>
export default {
  props: ['label', 'width', 'height', 'positionX', 'positionY'],
  computed: {
    style() {
      return `left: ${this.positionX}px;top: ${this.positionY}px;position: absolute;`
    },
    styledBtn() {
      return `width: ${this.width}px;height: ${this.height}px;`
    }
  }
}
</script>