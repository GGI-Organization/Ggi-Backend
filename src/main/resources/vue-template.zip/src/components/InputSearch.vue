<template>
  <div :style="style">
    <q-input outlined v-model="text" placeholder="Ingrese texto">
      <template v-slot:prepend>
        <q-icon name="search" />
      </template>
    </q-input>
  </div>
</template>

<script>
export default {
  props: ['width', 'positionX', 'positionY'],
  computed: {
    style() {
      return `width: ${this.width}px;left: ${this.positionX}px;top: ${this.positionY}px;position: absolute;`
    },
  }
}
</script>