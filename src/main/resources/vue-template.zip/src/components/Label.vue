
<template>
  <div :style="style">
    <div class="text-h5">
      Titulo
    </div>
  </div>
</template>

<script>
export default {
  props: ['label', 'width', 'height', 'positionX', 'positionY'],
  computed: {
    style() {
      return `left: ${this.positionX}px;top: ${this.positionY}px;position: absolute;`
    }
  }
}
</script>