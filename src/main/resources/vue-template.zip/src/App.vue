<template>
  <q-layout view="lHh Lpr lFf">
    <q-header elevated class="bg-primary text-white">
      <q-toolbar>
        <q-btn flat dense round icon="menu" @click="drawer = !drawer" class="q-mr-md" />
        <q-toolbar-title>
          Mi Aplicación
        </q-toolbar-title>
      </q-toolbar>
    </q-header>

    <q-drawer v-model="drawer" show-if-above :width="250" :breakpoint="600" :content-class="'bg-grey-2'">
      <q-list>
        <q-item clickable v-for="item in menuItems" :key="item.label" @click="navigateTo(item.route)">
          <q-item-section>
            <q-item-label>
              {{ item.label }}
            </q-item-label>
          </q-item-section>
        </q-item>
      </q-list>
    </q-drawer>
    <q-page-container>
      <router-view />
    </q-page-container>
  </q-layout>
</template>

<script>
import { RouterLink, RouterView } from 'vue-router'
export default {
  data() {
    return {
      drawer: false,
      menuItems: [
        { label: 'Inicio', icon: 'home', route: '/' },
        { label: 'Contacto', icon: 'mail', route: '/' },
      ],
    };
  },
  methods: {
    navigateTo(route) {
      this.$router.push(route);
      this.drawer = false;
    },
  },
};
</script>
